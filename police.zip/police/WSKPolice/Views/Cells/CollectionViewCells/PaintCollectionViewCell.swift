
import UIKit

class PaintCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var button: UIButton!
    
}
